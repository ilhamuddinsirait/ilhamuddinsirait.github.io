var clock = new Vue({
  el: '#clock',
  data: {
      time: '',
      date: ''
  }
});

var week = ['suday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
var timerID = setInterval(updateTime, 1000);
updateTime();
function updateTime() {
  var cd = new Date();
  clock.time = zeroPadding(cd.getHours(), 2) + ':' + zeroPadding(cd.getMinutes(), 2) + ':' + zeroPadding(cd.getSeconds(), 2);
  clock.date = zeroPadding(cd.getFullYear(), 4) + '-' + zeroPadding(cd.getMonth()+1, 2) + '-' + zeroPadding(cd.getDate(), 2) + ' ' + week[cd.getDay()];
};

function zeroPadding(num, digit) {
  var zero = '';
  for(var i = 0; i < digit; i++) {
      zero += '0';
  }
  return (zero + num).slice(-digit);
}


const about = document.querySelector('#about')
const contact = document.querySelector('#contact')
const paket = document.querySelector('#paket')
const aboutContent = document.querySelector('#about-content')
const contactContent = document.querySelector('#contact-content')
const paketContent = document.querySelector('#paket-content')

about.addEventListener('click', () => {
  const aboutBox = new WinBox({
    title: 'Tentang Kami',
    // modal: true,
    width: '370px',
    height: '300px',
    top: 150,
    right: 50,
    bottom: 50,
    left: 10,
    mount: aboutContent,
    onfocus: function () {
      this.setBackground('#00aa00')
    },
    onblur: function () {
      this.setBackground('#777')
    },
  })
})

contact.addEventListener('click', () => {
  const contactBox = new WinBox({
    title: 'Contact Kami',
    width: '370px',
    height: '300px',
    top: 150,
    right: 50,
    bottom: 50,
    left: 10,
    mount: contactContent,
    onfocus: function () {
      this.setBackground('#00aa00')
    },
    onblur: function () {
      this.setBackground('#777')
    },
  })
})

paket.addEventListener('click', () => {
  const paketBox = new WinBox({
    title: 'Paket Hotspot',
    width: '370px',
    height: '300px',
    top: 150,
    right: 50,
    bottom: 50,
    left: 10,
    mount: paketContent,
    onfocus: function () {
      this.setBackground('#00aa00')
    },
    onblur: function () {
      this.setBackground('#777')
    },
  })
})
